let divs = document.querySelectorAll('section div')
let button = document.querySelectorAll('nav a')

window.addEventListener('load', function(){
  button[0].click()
})

function showPage(page) {
  divs.forEach(div => {
    div.style.display = 'none';
  })
  document.querySelector(`#${page}`).style.display = 'block'
}

// make link active to click by changing color
function makeActiveLinks (){
  button.forEach(button => {
    button.style.color  = 'blue'
  })
  
}
document.querySelectorAll('a').forEach(button => {
  button.onclick = function() {
    makeActiveLinks()
    this.style.color = 'pink'
    showPage(this.dataset.page)
  }
})
